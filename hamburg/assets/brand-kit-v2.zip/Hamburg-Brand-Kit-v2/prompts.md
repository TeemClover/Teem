# Generation prompt set — 2026-10-07

Built-in imagegen tool. Transparent output for the two logo calls; opaque output for the three packaging calls. Independent calls per asset. No API key or CLI image generation used.

## TMT logo

Use case: logo-brand. Asset: final standalone Thai food brand logo for website and vacuum pouch label. Design a striking professionally crafted RED typographic logo with exactly the Thai brand name "เชื่อปากกู" and small secondary English "TMT". Thai spelling must be exact and perfectly readable including tone marks: เชื่อปากกู. Brand is confident Japanese hamburg steak with sauce, Thai streetwise food taste authority. Bold compact hand-cut lettering, mildly irregular confident custom Thai lettering rather than generic typed font. Stack เชื่อ above ปากกู in a compact rectangular stamp silhouette, small TMT integrated at the bottom; independent original identity, tasteful chef label rather than discount supermarket. Lacquer chili red #B72D26 only, transparent background, no white box, no shadows, no scene or mockup. Strong negative spaces and readable at small scale. No additional words, no mascot, no lips, no flags, no seal claiming certification, no watermark. Centered mark occupying most canvas with generous safe margin. High-quality clean edges suitable for print logo.

Output: `tmt/logo-master.png`. Generated source: exec-3d025355-7ace-49cf-8890-2ddb8f57e6db.png.

## Noomjang logo

Use case: logo-brand. Asset: final standalone Thai Japanese hamburg food brand logo for website and vacuum pouch label. Create a distinctive soft modern Thai wordmark with exact name "นุ่มจัง" and small uppercase supporting "NOOMJANG" underneath. Thai spelling including tone mark must be exact and perfectly readable: นุ่มจัง. Thick rounded custom letterforms with airy counters, sophisticated gentle tactile softness, subtle hand-drawn fullness and joyful understated personality. Add a simple small abstract double steam curve above one portion of lettering, integrated as a brand flourish. Single deep sage green #355A49, transparent background, no opaque rectangle. Horizontal broad wordmark 2:1 composition occupying central canvas, modest margins. Contemporary premium friendly food studio, visually very different from angular red stamp. No cartoon mascot, no face, no extra copy, no Japanese characters, no flags, no fake quality badges, no shadows, no scene, no mockup, no watermark. Crisp clean production-like artwork.

Output: `noomjang/logo-master.png`. Generated source: exec-000597a4-5016-4433-9387-68da9c1ef869.png.

## Shared packaging prompt prefix

Use case: product-mockup. Asset: realistic premium food vacuum-sealed pouch concept photo for a brand sales website. One physically plausible flat transparent food vacuum bag, heat-sealed 8mm edges, plastic tightly follows food contours with natural fine wrinkles and specular highlights, no air balloon, NO stand-up pouch, NO zipper, NO tray, NO box. Exactly TWO fully cooked oval Japanese hamburg patties and brown sauce vacuum-packed together in this single bag. Patties approximately 100g each, fine cooked meat texture, caramelized crust, sauce amount modest about 50g; no rice or vegetables inside bag. Both patties visibly identifiable through clear bag area. Label attached to OUTSIDE of clear plastic and occupies at most 35% bag front, food still clearly seen. Product-only editorial photography, no hands/person. Whole bag visible with margin, portrait-friendly 4:5 frame. No other brand assets, no fake nutrition, certificates, dates, weight, shelf life, barcodes or unsupported ingredient claims. Exact small secondary label text only: "แฮมเบิร์กญี่ปุ่น" and "2 ชิ้นพร้อมซอส". Brand reference image is a visual identity reference only; faithfully reproduce that exact brand mark on sticker, keep letter spelling, do not redesign it.

Production portion values in the image prompt are target-scale visual guidance from Product.md, not verified values printed on a sales label.

## Homechew packaging suffix + reference

Reference: `homechew/logo-reference.png`, rendered directly from approved original mark and wordmark SVG with Thai spelling โฮมชิว. Reference is brand identity, not an edit target.

Brand: HOMECHEW. Use the APPROVED original H shaped house/sauce-drop/bowl symbol AND original serif Homechew wordmark from reference; exact Thai subtitle "โฮมชิว". Warm crafted home kitchen identity. Sticker warm ivory rectangle with fine espresso border, generous editorial spacing, small copper divider, logo dark brown. Place sticker in upper portion; two patties arranged vertically below it. Bag laid flat on warm natural oak and oatmeal linen, high oblique camera angle, soft warm side window light. Minimal arrangement, no serving bowl. Elegant calm homestyle rather than rustic burlap. Preserve Homechew identity exactly. No invented new Homechew mark.

Output: `homechew/packaging-master.png`. Generated source: exec-ed98d1fc-968d-49e2-b761-811f6f9be9b2.png.

## TMT packaging suffix + reference

Reference: `tmt/logo-master.png`, brand identity reference, not an edit target.

Brand: เชื่อปากกู TMT. Faithfully use reference bold angular stacked Thai "เชื่อปากกู" red lettering with TMT. Label is a bold ivory vertical rectangle with strong lacquer chili red #B72D26 header/border blocks and black small product typography, crisp squared corners. Keep LOGO RED on IVORY area to preserve reference. Place label on left upper portion, two patties visible in clear right/bottom bag area. Bag diagonally laid on clean matte charcoal stone, tiny red paper accent entering frame lower left only, high contrast directional studio side light, modern confident food campaign. Red identity should dominate sticker; no warm home kitchen props.

Output: `tmt/packaging-master.png`. Generated source: exec-a3460813-5ec6-4bf2-9a4c-d693bd87eabb.png.

## Noomjang packaging suffix + reference

Reference: `noomjang/logo-master.png`, brand identity reference, not an edit target.

Brand: นุ่มจัง NOOMJANG. Faithfully use reference soft round Thai green "นุ่มจัง" wordmark and steam flourish, exact English NOOMJANG. Sticker is a die-cut rounded arch in pale sage #E5EEDB, logo deep green #355A49, small apricot #F0B991 semicircle design accent and carefully spaced supporting product text. Sticker upper portion of bag; two patties visible below. Bag laid flat on pale sage studio surface with light apricot paper shape as simple background accent, soft luminous diffused daylight, gentle shadows, straight-on near top-down view, polished clean contemporary tactile food brand. No wood, black stone, red, rustic props, no cartoon. Make it visibly distinct from red TMT and ivory/brown Homechew.

Output: `noomjang/packaging-master.png`. Generated source: exec-00ae8961-98fa-4815-8fb0-0de4f79252d9.png.

## Native artwork

Front/back SVG labels were composed directly using the approved Homechew vectors and embedded generated logo masters. Label copy remains editable text. Logo masters for TMT/Noomjang are raster originals; the SVG layout is not a traced vector version of those logos. Web asset optimization only: trim transparent outer canvas, resize, WebP encode. No creative alteration of the generated photographs.

## TMT packaging correction — selected replacement

The original TMT packaging image above was replaced following owner feedback about smeared logo printing. See [exact selected fresh-generation prompt](tmt/packaging-v2-prompt.md). Built-in imagegen, single approved logo reference, new upright top-down photograph with flat frontal matte label.
