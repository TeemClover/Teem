# Hamburg — Brand identity 2.0

2026-10-07 · three distinct directions, same product and offers.

## Delivered

- Homechew: original approved house/drop/bowl mark and serif wordmark copied exactly from `Teem/homechew/assets/brand/`; Thai spelling is โฮมชิว. Warm ivory, espresso, copper; thin framed label. No new Homechew logo.
- เชื่อปากกู / TMT: new angular stacked Thai logo, lacquer/chili red #B72D26, charcoal #181714, ivory #FFF6E8. Square label and confident red website.
- นุ่มจัง / NOOMJANG: new rounded Thai wordmark and steam flourish; deep green #355A49, sage #E5EEDB, apricot #F0B991. Arch label and tactile green website.

Each subfolder contains the original packaging PNG and editable SVG front/back label layout. TMT and Noomjang also include transparent PNG logo masters. Homechew references original vector artwork. Optimized web copies live in `../public/assets/{brand}/`. Live comparison route: `/hamburg/branding/`.

## Packaging construction represented

One transparent flat vacuum pouch with heat-sealed edges, two fully cooked patties with sauce inside, external adhesive label, food remains visible. Homechew rectilinear ivory label, TMT red bands and angular typography, Noomjang die-cut arch. Proposed front artwork sizes: Homechew/TMT 90×105 mm; Noomjang 95×95 mm. Back layout 70×100 mm. These are design-layout dimensions to fit against the actual pouch before production, not validated pouch specifications.

Back layouts leave blanks for actual ingredients/allergens, storage/shelf life, reheating, producer details, net weight and production/best-before/lot. No fabricated weight, dates, nutrition, certification or reviews appear in mockups. Current food and packaging images are generated concepts; no claim of actual product evidence or print-ready compliance.

## Generation

Built-in imagegen was used for two logo masters and three independently generated product mockups. Existing Homechew vectors were reused directly. Image optimization preserves alpha and composition. See `prompts.md` for the prompt set and references.

## Changelog

2.0: preserve approved Homechew mark, create distinct red/green identities, vacuum-pouch concepts and label artwork; integrate logos/packaging into arena, individual booths, checkout and brand comparison. Product, prices, carts and preview order behavior unchanged.
