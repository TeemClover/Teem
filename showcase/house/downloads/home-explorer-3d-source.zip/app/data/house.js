export const house = {
  "schemaVersion": "1.0",
  "title": "Home Explorer — educational geometry",
  "lengthUnit": "metre",
  "notice": "Study reference redrawn from supplied plans; not a construction drawing. Photography is not included.",
  "floors": [
    {
      "id": "f1",
      "elevation": 0
    },
    {
      "id": "f2",
      "elevation": 3.29
    }
  ],
  "rooms": [
    {
      "id": "f1-g01-living",
      "floor": "f1",
      "name": "ห้องรับแขก",
      "planLabel": "G01",
      "polygon": [
        [
          9.8,
          -6.9
        ],
        [
          14.1,
          -6.9
        ],
        [
          14.1,
          -2.05
        ],
        [
          9.8,
          -2.05
        ]
      ],
      "kind": "living",
      "levelOffset": 0,
      "evidenceStatus": "derived",
      "geometryStatus": "draft"
    },
    {
      "id": "f1-g02-rear-sitting",
      "floor": "f1",
      "name": "ห้องนั่งเล่น",
      "planLabel": "G02",
      "polygon": [
        [
          10.7,
          -10.3
        ],
        [
          14.1,
          -10.3
        ],
        [
          14.1,
          -6.9
        ],
        [
          10.7,
          -6.9
        ]
      ],
      "kind": "living",
      "levelOffset": 0,
      "evidenceStatus": "derived",
      "geometryStatus": "draft"
    },
    {
      "id": "f1-g03-dining",
      "floor": "f1",
      "name": "รับประทานอาหาร",
      "planLabel": "G03",
      "polygon": [
        [
          5.5,
          -6.9
        ],
        [
          9.8,
          -6.9
        ],
        [
          9.8,
          -2.05
        ],
        [
          5.5,
          -2.05
        ]
      ],
      "kind": "dining",
      "levelOffset": 0,
      "evidenceStatus": "derived",
      "geometryStatus": "draft"
    },
    {
      "id": "f1-g04-prep",
      "floor": "f1",
      "name": "เตรียมอาหาร",
      "planLabel": "G04",
      "polygon": [
        [
          3.3,
          -6.9
        ],
        [
          5.5,
          -6.9
        ],
        [
          5.5,
          -3.5
        ],
        [
          3.3,
          -3.5
        ]
      ],
      "kind": "kitchen",
      "levelOffset": 0,
      "evidenceStatus": "derived",
      "geometryStatus": "draft"
    },
    {
      "id": "f1-g05-kitchen",
      "floor": "f1",
      "name": "ครัว",
      "planLabel": "G05",
      "polygon": [
        [
          2.2,
          -10.3
        ],
        [
          5.5,
          -10.3
        ],
        [
          5.5,
          -6.9
        ],
        [
          2.2,
          -6.9
        ]
      ],
      "kind": "kitchen",
      "levelOffset": 0,
      "evidenceStatus": "derived",
      "geometryStatus": "draft"
    },
    {
      "id": "f1-g05-1-service-kitchen",
      "floor": "f1",
      "name": "ครัวไทย",
      "planLabel": "G05/1",
      "polygon": [
        [
          -0.6,
          -10.3
        ],
        [
          2.2,
          -10.3
        ],
        [
          2.2,
          -6.9
        ],
        [
          -0.6,
          -6.9
        ]
      ],
      "kind": "service",
      "levelOffset": -0.04,
      "evidenceStatus": "derived",
      "geometryStatus": "draft"
    },
    {
      "id": "f1-g06-bath",
      "floor": "f1",
      "name": "ห้องน้ำ",
      "planLabel": "G06",
      "polygon": [
        [
          8.5,
          -10.3
        ],
        [
          10.7,
          -10.3
        ],
        [
          10.7,
          -8
        ],
        [
          8.5,
          -8
        ]
      ],
      "kind": "bath",
      "levelOffset": -0.04,
      "evidenceStatus": "derived",
      "geometryStatus": "draft"
    },
    {
      "id": "f1-rear-hall",
      "floor": "f1",
      "name": "ทางเชื่อมด้านหลัง",
      "planLabel": null,
      "polygon": [
        [
          8.5,
          -8
        ],
        [
          10.7,
          -8
        ],
        [
          10.7,
          -6.9
        ],
        [
          8.5,
          -6.9
        ]
      ],
      "kind": "hall",
      "levelOffset": 0,
      "evidenceStatus": "derived",
      "geometryStatus": "draft"
    },
    {
      "id": "f1-g07-service-room",
      "floor": "f1",
      "name": "ห้องบริการ",
      "planLabel": "G07",
      "polygon": [
        [
          -0.6,
          -5.5
        ],
        [
          1.8,
          -5.5
        ],
        [
          1.8,
          -3.5
        ],
        [
          -0.6,
          -3.5
        ]
      ],
      "kind": "service",
      "levelOffset": 0,
      "evidenceStatus": "derived",
      "geometryStatus": "draft"
    },
    {
      "id": "f1-g08-service-bath",
      "floor": "f1",
      "name": "ห้องน้ำบริการ",
      "planLabel": "G08",
      "polygon": [
        [
          1.3,
          -6.9
        ],
        [
          3.3,
          -6.9
        ],
        [
          3.3,
          -5.5
        ],
        [
          1.3,
          -5.5
        ]
      ],
      "kind": "bath",
      "levelOffset": -0.08,
      "evidenceStatus": "derived",
      "geometryStatus": "draft"
    },
    {
      "id": "f1-service-passage",
      "floor": "f1",
      "name": "ทางเดินบริการ",
      "planLabel": null,
      "polygon": [
        [
          -0.6,
          -6.9
        ],
        [
          1.3,
          -6.9
        ],
        [
          1.3,
          -5.5
        ],
        [
          -0.6,
          -5.5
        ]
      ],
      "kind": "hall",
      "levelOffset": -0.04,
      "evidenceStatus": "derived",
      "geometryStatus": "draft"
    },
    {
      "id": "f1-service-entry",
      "floor": "f1",
      "name": "ทางเข้าบริการ",
      "planLabel": null,
      "polygon": [
        [
          1.8,
          -5.5
        ],
        [
          3.3,
          -5.5
        ],
        [
          3.3,
          -3.5
        ],
        [
          1.8,
          -3.5
        ]
      ],
      "kind": "hall",
      "levelOffset": -0.04,
      "evidenceStatus": "derived",
      "geometryStatus": "draft"
    },
    {
      "id": "f1-g09-storage",
      "floor": "f1",
      "name": "ห้องเก็บของ",
      "planLabel": "G09",
      "polygon": [
        [
          5.5,
          -10.3
        ],
        [
          8.5,
          -10.3
        ],
        [
          8.5,
          -9.25
        ],
        [
          5.5,
          -9.25
        ]
      ],
      "kind": "service",
      "levelOffset": 0,
      "evidenceStatus": "derived",
      "geometryStatus": "draft"
    },
    {
      "id": "f1-stair",
      "floor": "f1",
      "name": "บันได",
      "planLabel": null,
      "polygon": [
        [
          5.5,
          -9.25
        ],
        [
          8.5,
          -9.25
        ],
        [
          8.5,
          -6.9
        ],
        [
          5.5,
          -6.9
        ]
      ],
      "kind": "stair",
      "levelOffset": 0,
      "evidenceStatus": "derived",
      "geometryStatus": "draft"
    },
    {
      "id": "f1-g10-porch",
      "floor": "f1",
      "name": "เฉลียง",
      "planLabel": "G10",
      "polygon": [
        [
          9.8,
          -2.05
        ],
        [
          14.35,
          -2.05
        ],
        [
          14.35,
          -0.8
        ],
        [
          9.8,
          -0.8
        ]
      ],
      "kind": "balcony",
      "levelOffset": -0.04,
      "evidenceStatus": "derived",
      "geometryStatus": "draft"
    },
    {
      "id": "f1-entry-terrace",
      "floor": "f1",
      "name": "ทางเข้าบ้าน",
      "planLabel": null,
      "polygon": [
        [
          5.5,
          -2.05
        ],
        [
          9.8,
          -2.05
        ],
        [
          9.8,
          0
        ],
        [
          5.5,
          0
        ]
      ],
      "kind": "balcony",
      "levelOffset": -0.195,
      "evidenceStatus": "derived",
      "geometryStatus": "draft"
    },
    {
      "id": "f1-carport",
      "floor": "f1",
      "name": "ที่จอดรถ",
      "planLabel": null,
      "polygon": [
        [
          0,
          -3.5
        ],
        [
          5.5,
          -3.5
        ],
        [
          5.5,
          0.6
        ],
        [
          0,
          0.6
        ]
      ],
      "kind": "carport",
      "levelOffset": -0.35,
      "evidenceStatus": "derived",
      "geometryStatus": "draft"
    },
    {
      "id": "f1-g12-laundry",
      "floor": "f1",
      "name": "ซักล้าง",
      "planLabel": "G12",
      "polygon": [
        [
          0,
          -11.85
        ],
        [
          2.75,
          -11.85
        ],
        [
          2.75,
          -10.3
        ],
        [
          0,
          -10.3
        ]
      ],
      "kind": "service",
      "levelOffset": -0.35,
      "evidenceStatus": "derived",
      "geometryStatus": "draft"
    },
    {
      "id": "f2-201-bedroom",
      "floor": "f2",
      "name": "ห้องนอน 201",
      "planLabel": "201",
      "polygon": [
        [
          9.8,
          -6.9
        ],
        [
          14.1,
          -6.9
        ],
        [
          14.1,
          -1.85
        ],
        [
          9.8,
          -1.85
        ]
      ],
      "kind": "bedroom",
      "levelOffset": 0,
      "evidenceStatus": "derived",
      "geometryStatus": "draft"
    },
    {
      "id": "f2-201-1-dressing",
      "floor": "f2",
      "name": "ห้องแต่งตัว",
      "planLabel": "201/1",
      "polygon": [
        [
          11.6,
          -10.3
        ],
        [
          14.1,
          -10.3
        ],
        [
          14.1,
          -6.9
        ],
        [
          11.6,
          -6.9
        ]
      ],
      "kind": "service",
      "levelOffset": 0,
      "evidenceStatus": "derived",
      "geometryStatus": "draft"
    },
    {
      "id": "f2-202-bedroom",
      "floor": "f2",
      "name": "ห้องนอน 202",
      "planLabel": "202",
      "polygon": [
        [
          3.3,
          -5.2
        ],
        [
          5.5,
          -5.2
        ],
        [
          5.5,
          0
        ],
        [
          0,
          0
        ],
        [
          0,
          -3.5
        ],
        [
          3.3,
          -3.5
        ]
      ],
      "kind": "bedroom",
      "levelOffset": 0,
      "evidenceStatus": "derived",
      "geometryStatus": "draft"
    },
    {
      "id": "f2-203-bedroom",
      "floor": "f2",
      "name": "ห้องนอน 203",
      "planLabel": "203",
      "polygon": [
        [
          0,
          -10.3
        ],
        [
          5.5,
          -10.3
        ],
        [
          5.5,
          -6.9
        ],
        [
          0,
          -6.9
        ]
      ],
      "kind": "bedroom",
      "levelOffset": 0,
      "evidenceStatus": "derived",
      "geometryStatus": "draft"
    },
    {
      "id": "f2-204-hall",
      "floor": "f2",
      "name": "โถงชั้นบน",
      "planLabel": "204",
      "polygon": [
        [
          3.3,
          -6.9
        ],
        [
          5.5,
          -6.9
        ],
        [
          5.5,
          -7.4
        ],
        [
          8.5,
          -7.4
        ],
        [
          8.5,
          -9.15
        ],
        [
          9.65,
          -9.15
        ],
        [
          9.65,
          -6.9
        ],
        [
          9.8,
          -6.9
        ],
        [
          9.8,
          -5.2
        ],
        [
          3.3,
          -5.2
        ]
      ],
      "kind": "hall",
      "levelOffset": 0,
      "evidenceStatus": "derived",
      "geometryStatus": "draft"
    },
    {
      "id": "f2-204-1-lounge",
      "floor": "f2",
      "name": "ห้องพักผ่อน",
      "planLabel": "204/1",
      "polygon": [
        [
          5.5,
          -5.2
        ],
        [
          9.8,
          -5.2
        ],
        [
          9.8,
          -1.6
        ],
        [
          5.5,
          -1.6
        ]
      ],
      "kind": "lounge",
      "levelOffset": 0,
      "evidenceStatus": "derived",
      "geometryStatus": "draft"
    },
    {
      "id": "f2-205-bath",
      "floor": "f2",
      "name": "ห้องน้ำ 205",
      "planLabel": "205",
      "polygon": [
        [
          9.65,
          -10.3
        ],
        [
          11.6,
          -10.3
        ],
        [
          11.6,
          -6.9
        ],
        [
          9.65,
          -6.9
        ]
      ],
      "kind": "bath",
      "levelOffset": -0.04,
      "evidenceStatus": "derived",
      "geometryStatus": "draft"
    },
    {
      "id": "f2-206-bath",
      "floor": "f2",
      "name": "ห้องน้ำ 206",
      "planLabel": "206",
      "polygon": [
        [
          0,
          -5.2
        ],
        [
          3.3,
          -5.2
        ],
        [
          3.3,
          -3.5
        ],
        [
          0,
          -3.5
        ]
      ],
      "kind": "bath",
      "levelOffset": -0.04,
      "evidenceStatus": "derived",
      "geometryStatus": "draft"
    },
    {
      "id": "f2-207-bath",
      "floor": "f2",
      "name": "ห้องน้ำ 207",
      "planLabel": "207",
      "polygon": [
        [
          0,
          -6.9
        ],
        [
          3.3,
          -6.9
        ],
        [
          3.3,
          -5.2
        ],
        [
          0,
          -5.2
        ]
      ],
      "kind": "bath",
      "levelOffset": -0.04,
      "evidenceStatus": "derived",
      "geometryStatus": "draft"
    },
    {
      "id": "f2-208-vent-space",
      "floor": "f2",
      "name": "ช่องลม",
      "planLabel": "208",
      "polygon": [
        [
          8.5,
          -10.3
        ],
        [
          9.65,
          -10.3
        ],
        [
          9.65,
          -9.15
        ],
        [
          8.5,
          -9.15
        ]
      ],
      "kind": "void",
      "levelOffset": -0.04,
      "evidenceStatus": "derived",
      "geometryStatus": "draft"
    },
    {
      "id": "f2-209-balcony",
      "floor": "f2",
      "name": "ระเบียง 209",
      "planLabel": "209",
      "polygon": [
        [
          9.8,
          -1.85
        ],
        [
          14.35,
          -1.85
        ],
        [
          14.35,
          -0.8
        ],
        [
          13.4,
          -0.8
        ],
        [
          13.4,
          -0.4
        ],
        [
          9.3,
          -0.4
        ],
        [
          9.3,
          -1.6
        ],
        [
          9.8,
          -1.6
        ]
      ],
      "kind": "balcony",
      "levelOffset": -0.04,
      "evidenceStatus": "derived",
      "geometryStatus": "draft"
    },
    {
      "id": "f2-210-balcony",
      "floor": "f2",
      "name": "ระเบียง 210",
      "planLabel": "210",
      "polygon": [
        [
          0,
          0
        ],
        [
          5.5,
          0
        ],
        [
          5.5,
          0.6
        ],
        [
          4.8,
          0.6
        ],
        [
          4.8,
          0.95
        ],
        [
          0.6,
          0.95
        ],
        [
          0.6,
          0.6
        ],
        [
          0,
          0.6
        ]
      ],
      "kind": "balcony",
      "levelOffset": -0.04,
      "evidenceStatus": "derived",
      "geometryStatus": "draft"
    },
    {
      "id": "f2-211-service-roof",
      "floor": "f2",
      "name": "หลังคาพื้นที่บริการ",
      "planLabel": "211",
      "polygon": [
        [
          -0.6,
          -10.3
        ],
        [
          0,
          -10.3
        ],
        [
          0,
          -3.5
        ],
        [
          -0.6,
          -3.5
        ]
      ],
      "kind": "service",
      "levelOffset": -0.04,
      "evidenceStatus": "derived",
      "geometryStatus": "draft"
    }
  ],
  "walls": [
    {
      "id": "f1-back",
      "floor": "f1",
      "a": [
        -0.6,
        -10.3
      ],
      "b": [
        14.1,
        -10.3
      ],
      "exterior": true,
      "height": 2.7,
      "openings": [
        {
          "offset": 0.4,
          "width": 1.6,
          "height": 1.1,
          "sill": 1.1,
          "kind": "window"
        },
        {
          "offset": 3.1,
          "width": 2.7,
          "height": 1.15,
          "sill": 1.05,
          "kind": "window"
        },
        {
          "offset": 9.2,
          "width": 0.55,
          "height": 0.6,
          "sill": 1.7,
          "kind": "window"
        },
        {
          "offset": 11.65,
          "width": 2.45,
          "height": 2.25,
          "sill": 0,
          "kind": "window"
        }
      ],
      "thickness": 0.15
    },
    {
      "id": "f1-east",
      "floor": "f1",
      "a": [
        14.1,
        -10.3
      ],
      "b": [
        14.1,
        -2.05
      ],
      "exterior": true,
      "height": 2.7,
      "openings": [
        {
          "offset": 0.9,
          "width": 1.75,
          "height": 2.25,
          "sill": 0,
          "kind": "window"
        },
        {
          "offset": 3.85,
          "width": 3.15,
          "height": 2.25,
          "sill": 0,
          "kind": "window"
        }
      ],
      "thickness": 0.15
    },
    {
      "id": "f1-front",
      "floor": "f1",
      "a": [
        5.5,
        -2.05
      ],
      "b": [
        14.1,
        -2.05
      ],
      "exterior": true,
      "height": 2.7,
      "openings": [
        {
          "offset": 0.8,
          "width": 1.4,
          "height": 2.2,
          "sill": 0,
          "kind": "window"
        },
        {
          "offset": 4.55,
          "width": 3.1,
          "height": 2.3,
          "sill": 0,
          "kind": "door"
        }
      ],
      "thickness": 0.15
    },
    {
      "id": "f1-west",
      "floor": "f1",
      "a": [
        -0.6,
        -10.3
      ],
      "b": [
        -0.6,
        -3.5
      ],
      "exterior": true,
      "height": 2.7,
      "openings": [
        {
          "offset": 0.5,
          "width": 1.5,
          "height": 1.1,
          "sill": 1.1,
          "kind": "window"
        },
        {
          "offset": 3.45,
          "width": 0.8,
          "height": 2.05,
          "sill": 0,
          "kind": "door"
        },
        {
          "offset": 5.35,
          "width": 1,
          "height": 1.3,
          "sill": 0.85,
          "kind": "window"
        }
      ],
      "thickness": 0.15
    },
    {
      "id": "f1-service-front",
      "floor": "f1",
      "a": [
        -0.6,
        -3.5
      ],
      "b": [
        3.3,
        -3.5
      ],
      "exterior": true,
      "height": 2.7,
      "openings": [
        {
          "offset": 2.55,
          "width": 0.85,
          "height": 2.05,
          "sill": 0,
          "kind": "door"
        }
      ],
      "thickness": 0.15
    },
    {
      "id": "f1-prep-front",
      "floor": "f1",
      "a": [
        3.3,
        -3.5
      ],
      "b": [
        5.5,
        -3.5
      ],
      "exterior": true,
      "height": 2.7,
      "openings": [
        {
          "offset": 0.45,
          "width": 1.2,
          "height": 2.1,
          "sill": 0,
          "kind": "door"
        }
      ],
      "thickness": 0.15
    },
    {
      "id": "f1-dining-west",
      "floor": "f1",
      "a": [
        5.5,
        -3.5
      ],
      "b": [
        5.5,
        -2.05
      ],
      "exterior": true,
      "height": 2.7,
      "openings": [
        {
          "offset": 0.25,
          "width": 0.85,
          "height": 2.1,
          "sill": 0,
          "kind": "door"
        }
      ],
      "thickness": 0.15
    },
    {
      "id": "f1-kitchen-west",
      "floor": "f1",
      "a": [
        2.2,
        -10.3
      ],
      "b": [
        2.2,
        -6.9
      ],
      "exterior": false,
      "height": 2.7,
      "openings": [
        {
          "offset": 1.95,
          "width": 0.9,
          "height": 2.1,
          "sill": 0,
          "kind": "door"
        }
      ],
      "thickness": 0.1
    },
    {
      "id": "f1-kitchen-east",
      "floor": "f1",
      "a": [
        5.5,
        -10.3
      ],
      "b": [
        5.5,
        -6.9
      ],
      "exterior": false,
      "height": 2.7,
      "openings": [
        {
          "offset": 2.35,
          "width": 0.85,
          "height": 2.1,
          "sill": 0,
          "kind": "door"
        }
      ],
      "thickness": 0.1
    },
    {
      "id": "f1-kitchen-front",
      "floor": "f1",
      "a": [
        2.2,
        -6.9
      ],
      "b": [
        5.5,
        -6.9
      ],
      "exterior": false,
      "height": 2.7,
      "openings": [
        {
          "offset": 1.2,
          "width": 1.6,
          "height": 2.25,
          "sill": 0,
          "kind": "open-passage"
        }
      ],
      "thickness": 0.1
    },
    {
      "id": "f1-service-divide",
      "floor": "f1",
      "a": [
        -0.6,
        -6.9
      ],
      "b": [
        2.2,
        -6.9
      ],
      "exterior": false,
      "height": 2.7,
      "openings": [
        {
          "offset": 0.55,
          "width": 0.9,
          "height": 2.05,
          "sill": 0,
          "kind": "door"
        }
      ],
      "thickness": 0.1
    },
    {
      "id": "f1-service-room-back",
      "floor": "f1",
      "a": [
        -0.6,
        -5.5
      ],
      "b": [
        3.3,
        -5.5
      ],
      "exterior": false,
      "height": 2.7,
      "openings": [
        {
          "offset": 2.55,
          "width": 0.8,
          "height": 2.05,
          "sill": 0,
          "kind": "door"
        }
      ],
      "thickness": 0.1
    },
    {
      "id": "f1-service-room-east",
      "floor": "f1",
      "a": [
        1.8,
        -5.5
      ],
      "b": [
        1.8,
        -3.5
      ],
      "exterior": false,
      "height": 2.7,
      "openings": [
        {
          "offset": 0.25,
          "width": 0.8,
          "height": 2.05,
          "sill": 0,
          "kind": "door"
        }
      ],
      "thickness": 0.1
    },
    {
      "id": "f1-service-bath-west",
      "floor": "f1",
      "a": [
        1.3,
        -6.9
      ],
      "b": [
        1.3,
        -5.5
      ],
      "exterior": false,
      "height": 2.7,
      "openings": [
        {
          "offset": 0.2,
          "width": 0.7,
          "height": 2,
          "sill": 0,
          "kind": "door"
        }
      ],
      "thickness": 0.1
    },
    {
      "id": "f1-prep-west",
      "floor": "f1",
      "a": [
        3.3,
        -6.9
      ],
      "b": [
        3.3,
        -3.5
      ],
      "exterior": false,
      "height": 2.7,
      "openings": [
        {
          "offset": 1.9,
          "width": 0.85,
          "height": 2.05,
          "sill": 0,
          "kind": "door"
        }
      ],
      "thickness": 0.1
    },
    {
      "id": "f1-bath-west",
      "floor": "f1",
      "a": [
        8.5,
        -10.3
      ],
      "b": [
        8.5,
        -8
      ],
      "exterior": false,
      "height": 2.7,
      "openings": [],
      "thickness": 0.1
    },
    {
      "id": "f1-bath-east",
      "floor": "f1",
      "a": [
        10.7,
        -10.3
      ],
      "b": [
        10.7,
        -8
      ],
      "exterior": false,
      "height": 2.7,
      "openings": [],
      "thickness": 0.1
    },
    {
      "id": "f1-bath-front",
      "floor": "f1",
      "a": [
        8.5,
        -8
      ],
      "b": [
        10.7,
        -8
      ],
      "exterior": false,
      "height": 2.7,
      "openings": [
        {
          "offset": 0.4,
          "width": 0.8,
          "height": 2.05,
          "sill": 0,
          "kind": "door"
        }
      ],
      "thickness": 0.1
    },
    {
      "id": "f1-rear-sitting-partition",
      "floor": "f1",
      "a": [
        10.7,
        -6.9
      ],
      "b": [
        14.1,
        -6.9
      ],
      "exterior": false,
      "height": 2.7,
      "openings": [
        {
          "offset": 0.35,
          "width": 2.7,
          "height": 2.4,
          "sill": 0,
          "kind": "open-passage"
        }
      ],
      "thickness": 0.1
    },
    {
      "id": "f2-back",
      "floor": "f2",
      "a": [
        0,
        -10.3
      ],
      "b": [
        14.1,
        -10.3
      ],
      "exterior": true,
      "height": 2.7,
      "openings": [
        {
          "offset": 0.55,
          "width": 2.3,
          "height": 1.8,
          "sill": 0.5,
          "kind": "window"
        },
        {
          "offset": 5.75,
          "width": 1,
          "height": 1.15,
          "sill": 1.05,
          "kind": "window"
        },
        {
          "offset": 9.95,
          "width": 0.9,
          "height": 0.65,
          "sill": 1.6,
          "kind": "window"
        }
      ],
      "thickness": 0.15
    },
    {
      "id": "f2-west",
      "floor": "f2",
      "a": [
        0,
        -10.3
      ],
      "b": [
        0,
        0
      ],
      "exterior": true,
      "height": 2.7,
      "openings": [
        {
          "offset": 0.7,
          "width": 2.1,
          "height": 1.8,
          "sill": 0.5,
          "kind": "window"
        },
        {
          "offset": 3.65,
          "width": 0.7,
          "height": 0.6,
          "sill": 1.6,
          "kind": "window"
        },
        {
          "offset": 5.45,
          "width": 0.65,
          "height": 0.6,
          "sill": 1.6,
          "kind": "window"
        },
        {
          "offset": 7.3,
          "width": 1.6,
          "height": 1.8,
          "sill": 0.5,
          "kind": "window"
        }
      ],
      "thickness": 0.15
    },
    {
      "id": "f2-east",
      "floor": "f2",
      "a": [
        14.1,
        -10.3
      ],
      "b": [
        14.1,
        -1.85
      ],
      "exterior": true,
      "height": 2.7,
      "openings": [
        {
          "offset": 4,
          "width": 1.8,
          "height": 1.8,
          "sill": 0.5,
          "kind": "window"
        },
        {
          "offset": 6.4,
          "width": 1.25,
          "height": 1.8,
          "sill": 0.5,
          "kind": "window"
        }
      ],
      "thickness": 0.15
    },
    {
      "id": "f2-front-left",
      "floor": "f2",
      "a": [
        0,
        0
      ],
      "b": [
        5.5,
        0
      ],
      "exterior": true,
      "height": 2.7,
      "openings": [
        {
          "offset": 1.15,
          "width": 3.15,
          "height": 2.3,
          "sill": 0,
          "kind": "door"
        }
      ],
      "thickness": 0.15
    },
    {
      "id": "f2-front-center",
      "floor": "f2",
      "a": [
        5.5,
        -1.6
      ],
      "b": [
        9.8,
        -1.6
      ],
      "exterior": true,
      "height": 2.7,
      "openings": [
        {
          "offset": 0.8,
          "width": 2.55,
          "height": 2.15,
          "sill": 0.15,
          "kind": "window"
        }
      ],
      "thickness": 0.15
    },
    {
      "id": "f2-front-right",
      "floor": "f2",
      "a": [
        9.8,
        -1.85
      ],
      "b": [
        14.1,
        -1.85
      ],
      "exterior": true,
      "height": 2.7,
      "openings": [
        {
          "offset": 0.45,
          "width": 3.15,
          "height": 2.3,
          "sill": 0,
          "kind": "door"
        }
      ],
      "thickness": 0.15
    },
    {
      "id": "f2-left-return",
      "floor": "f2",
      "a": [
        5.5,
        -1.6
      ],
      "b": [
        5.5,
        0
      ],
      "exterior": true,
      "height": 2.7,
      "openings": [],
      "thickness": 0.15
    },
    {
      "id": "f2-right-return",
      "floor": "f2",
      "a": [
        9.8,
        -1.85
      ],
      "b": [
        9.8,
        -1.6
      ],
      "exterior": true,
      "height": 2.7,
      "openings": [],
      "thickness": 0.15
    },
    {
      "id": "f2-203-east",
      "floor": "f2",
      "a": [
        5.5,
        -10.3
      ],
      "b": [
        5.5,
        -6.9
      ],
      "exterior": false,
      "height": 2.7,
      "openings": [],
      "thickness": 0.1
    },
    {
      "id": "f2-203-front",
      "floor": "f2",
      "a": [
        0,
        -6.9
      ],
      "b": [
        5.5,
        -6.9
      ],
      "exterior": false,
      "height": 2.7,
      "openings": [
        {
          "offset": 3.75,
          "width": 0.85,
          "height": 2.1,
          "sill": 0,
          "kind": "door"
        }
      ],
      "thickness": 0.1
    },
    {
      "id": "f2-baths-east",
      "floor": "f2",
      "a": [
        3.3,
        -6.9
      ],
      "b": [
        3.3,
        -3.5
      ],
      "exterior": false,
      "height": 2.7,
      "openings": [
        {
          "offset": 0.35,
          "width": 0.75,
          "height": 2.05,
          "sill": 0,
          "kind": "door"
        },
        {
          "offset": 2.2,
          "width": 0.75,
          "height": 2.05,
          "sill": 0,
          "kind": "door"
        }
      ],
      "thickness": 0.1
    },
    {
      "id": "f2-middle-partition",
      "floor": "f2",
      "a": [
        0,
        -5.2
      ],
      "b": [
        9.8,
        -5.2
      ],
      "exterior": false,
      "height": 2.7,
      "openings": [
        {
          "offset": 3.55,
          "width": 0.85,
          "height": 2.1,
          "sill": 0,
          "kind": "door"
        },
        {
          "offset": 6.15,
          "width": 2.75,
          "height": 2.3,
          "sill": 0,
          "kind": "open-passage"
        }
      ],
      "thickness": 0.1
    },
    {
      "id": "f2-206-front",
      "floor": "f2",
      "a": [
        0,
        -3.5
      ],
      "b": [
        3.3,
        -3.5
      ],
      "exterior": false,
      "height": 2.7,
      "openings": [],
      "thickness": 0.1
    },
    {
      "id": "f2-202-east",
      "floor": "f2",
      "a": [
        5.5,
        -5.2
      ],
      "b": [
        5.5,
        -1.6
      ],
      "exterior": false,
      "height": 2.7,
      "openings": [],
      "thickness": 0.1
    },
    {
      "id": "f2-201-west",
      "floor": "f2",
      "a": [
        9.8,
        -6.9
      ],
      "b": [
        9.8,
        -1.85
      ],
      "exterior": false,
      "height": 2.7,
      "openings": [
        {
          "offset": 0.5,
          "width": 0.95,
          "height": 2.15,
          "sill": 0,
          "kind": "door"
        }
      ],
      "thickness": 0.1
    },
    {
      "id": "f2-201-rear",
      "floor": "f2",
      "a": [
        9.8,
        -6.9
      ],
      "b": [
        14.1,
        -6.9
      ],
      "exterior": false,
      "height": 2.7,
      "openings": [
        {
          "offset": 0.35,
          "width": 0.75,
          "height": 2.05,
          "sill": 0,
          "kind": "door"
        },
        {
          "offset": 2.4,
          "width": 1.2,
          "height": 2.2,
          "sill": 0,
          "kind": "open-passage"
        }
      ],
      "thickness": 0.1
    },
    {
      "id": "f2-dressing-west",
      "floor": "f2",
      "a": [
        11.6,
        -10.3
      ],
      "b": [
        11.6,
        -6.9
      ],
      "exterior": false,
      "height": 2.7,
      "openings": [],
      "thickness": 0.1
    },
    {
      "id": "f2-bath-west",
      "floor": "f2",
      "a": [
        9.65,
        -10.3
      ],
      "b": [
        9.65,
        -6.9
      ],
      "exterior": false,
      "height": 2.7,
      "openings": [],
      "thickness": 0.1
    }
  ],
  "stair": {
    "holePolygon": [
      [
        5.5,
        -10.3
      ],
      [
        8.5,
        -10.3
      ],
      [
        8.5,
        -7.4
      ],
      [
        5.5,
        -7.4
      ]
    ],
    "bounds": [
      5.5,
      -10.3,
      8.5,
      -6.9
    ],
    "stepCount": 20,
    "stepCountStatus": "assumed"
  },
  "assumptions": {
    "wallHeight": 2.7,
    "slabThickness": 0.18,
    "exteriorWallThickness": 0.15,
    "interiorWallThickness": 0.1,
    "cutawayHeight": 0.9
  },
  "roof": {
    "height": 1.2,
    "overhang": 0.35,
    "status": "assumed"
  }
};
