// Add only photographs you have permission to use. See README.md.
export const photoSets = [];
